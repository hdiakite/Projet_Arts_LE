import React from 'react';
import TestRequests from '../components/TestRequests';

const PageTestRequests = () => {
  return (
    <div className="">
      <TestRequests />
    </div>
  );
};

export default PageTestRequests;
