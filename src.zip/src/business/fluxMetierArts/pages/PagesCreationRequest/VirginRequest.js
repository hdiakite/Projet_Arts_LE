import React from 'react';
import TestRequestForm from '../../components/TestRequestForm';

function VirginRequest() {
  return (
    <div>
      <TestRequestForm />
    </div>
  );
}
export default VirginRequest;
