import React from 'react';
import TestRequestDetail from './TestRequestDetail';
import ComponentValidateTestRequest from './ComponentValidateTestRequest';

function ValidationTestRequests() {
  return (
    <div>
      <TestRequestDetail />
      <ComponentValidateTestRequest />
    </div>
  );
}
export default ValidationTestRequests;
